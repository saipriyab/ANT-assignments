
public class Guitar {
public void play()
{
	System.out.println("Guitar is playing");
}
}
